export const testEnvironment = 'node';
